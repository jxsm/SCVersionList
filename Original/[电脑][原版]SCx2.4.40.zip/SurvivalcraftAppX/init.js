﻿//init.js - 在JS引擎初始化后执行

//导入命名空间
var _Game = importNamespace("Game");//Survivalcraft.exe
var _Engine = importNamespace("Engine");//Engine.dll
var _GameEnitySystem = importNamespace("GameEnitySystem");//EnitySystem.dll
var _Launcher = importNamespace("Launcher");//Launcher.exe
var  _System = importNamespace("System");

//写日志
var info = _Engine.Log.Information;//info("Information.");
var warn = _Engine.Log.Warning;//warn("Warning.");
var error = _Engine.Log.Error;//error("Error.");

//Engine.dll的常用类
var Vector2 = _Engine.Vector2;
var Vector3 = _Engine.Vector3;
var Vector4 = _Engine.Vector4;
var Point2 = _Engine.Point2;
var Point3 = _Engine.Point3;
var Color = _Engine.Color;
var Matrix = _Engine.Matrix;
var Storage = _Engine.Storage;

var isKeyDown = _Engine.Input.Keyboard.IsKeyDown;
var Keys = _Engine.Input.Key;

//Launcher.exe的接口
var getBlocksData = _Launcher.JsInterface.getBlocksData;//获得方块数据数组: getBlocksData()[1].DefaultDisplayName="Bad Rock";
var copyTerrain = _Launcher.JsInterface.copyTerrain;//copyTerrain(vector3 start,vector3 end,vector3 dest)
var setDatabaseValue = _Launcher.JsInterface.setDatabaseValue;//设置DatabaseObject的Value

//Game.dll的接口
var CellFace = _Game.CellFace
var faceToPoint3 = CellFace.faceToPoint3
var faceToVector3 = CellFace.faceToVector3;
var point3ToFace = CellFace.point3ToFace;
var vector3ToFace = CellFace.Vector3ToFace;

var extractContents = _Game.TerrainData.ExtractContents;//从方块value中提取方块的index
var extractData = _Game.TerrainData.ExtractData;//从方块的value中提取方块的附加数据
var extractLight = _Game.TerrainData.ExtractLight;//从方块的value中提取方块的光强度
var makeBlockValue = _Game.TerrainData.MakeBlockValue;//生成一个value: var value=MakeBlockValue(contents, light, temData);
var replaceContents = _Game.TerrainData.ReplaceContents;
var replaceItemData = _Game.TerrainData.ReplaceItemData;
var replaceLight = _Game.TerrainData.ReplaceLight;

//预定义函数

function Module(path) {
    //模块，限制作用域，方便卸载
    //从指定路径加载JS源码文件
    var code = Storage.ReadAllText(path);
    eval(code);
    this.path = path;
    this.reload = function () {
        var code = Storage.ReadAllText(this.path);
        eval(code);
    }
}

_modules = new Object();

function loadModule(name, path) {
    //装载模块
    module = new Module(path);
    _modules[name] = module;
    return module;
}

function getModule(name) {
    if (name in _modules) {
        return _modules[name];
    }
    return null;
}

//载入config.js
var config = loadModule("config", "app:js\\config.js");
