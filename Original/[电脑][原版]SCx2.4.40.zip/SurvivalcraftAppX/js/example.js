﻿//example.js - 从init.js载入

var event = getModule("event");
var game = getModule("game");
var addition = getModule("addition");
var module = this;

//在指定位置画圆,value是方块类型
this.drawCircle = function (x0, y0, z0, r, value) {
    if (game.world == null) {
        return;
    }
    with (game.world) {
        for (var x = 0; x < r; ++x) {
            var z = Math.sqrt(r * r - x * x);
            placeBlock(x0 + x, y0, z0 + z, value);
            placeBlock(x0 + x, y0, z0 - z, value);
            placeBlock(x0 - x, y0, z0 + z, value);
            placeBlock(x0 - x, y0, z0 - z, value);
        }
        for (var z = 0; z < r; ++z) {
            var x = Math.sqrt(r * r - z * z);
            placeBlock(x0 + x, y0, z0 + z, value);
            placeBlock(x0 + x, y0, z0 - z, value);
            placeBlock(x0 - x, y0, z0 + z, value);
            placeBlock(x0 - x, y0, z0 - z, value);
        }
    }
}
//在指定位置画球,value是方块类型
this.drawBall = function (x0, y0, z0, r, value) {
    if (game.world == null) {
        return;
    }
    with (game.world) {
        for (var x = 0; x < r; ++x) {
            for (var z = 0; z < r; ++z) {
                var y = Math.sqrt(r * r - x * x - z * z);
                if (y != y) {
                    continue;
                }
                placeBlock(x0 + x, y0 + y, z0 + z, value);
                placeBlock(x0 + x, y0 + y, z0 - z, value);
                placeBlock(x0 + x, y0 - y, z0 + z, value);
                placeBlock(x0 + x, y0 - y, z0 - z, value);
                placeBlock(x0 - x, y0 + y, z0 + z, value);
                placeBlock(x0 - x, y0 + y, z0 - z, value);
                placeBlock(x0 - x, y0 - y, z0 + z, value);
                placeBlock(x0 - x, y0 - y, z0 - z, value);
            }
        }
        for (var x = 0; x < r; ++x) {
            for (var y = 0; y < r; ++y) {
                var z = Math.sqrt(r * r - x * x - y * y);
                if (z != z) {
                    continue;
                }
                placeBlock(x0 + x, y0 + y, z0 + z, value);
                placeBlock(x0 + x, y0 + y, z0 - z, value);
                placeBlock(x0 + x, y0 - y, z0 + z, value);
                placeBlock(x0 + x, y0 - y, z0 - z, value);
                placeBlock(x0 - x, y0 + y, z0 + z, value);
                placeBlock(x0 - x, y0 + y, z0 - z, value);
                placeBlock(x0 - x, y0 - y, z0 + z, value);
                placeBlock(x0 - x, y0 - y, z0 - z, value);
            }
        }
        for (var y = 0; y < r; ++y) {
            for (var z = 0; z < r; ++z) {
                var x = Math.sqrt(r * r - y * y - z * z);
                if (x != x) {
                    continue;
                }
                placeBlock(x0 + x, y0 + y, z0 + z, value);
                placeBlock(x0 + x, y0 + y, z0 - z, value);
                placeBlock(x0 + x, y0 - y, z0 + z, value);
                placeBlock(x0 + x, y0 - y, z0 - z, value);
                placeBlock(x0 - x, y0 + y, z0 + z, value);
                placeBlock(x0 - x, y0 + y, z0 - z, value);
                placeBlock(x0 - x, y0 - y, z0 + z, value);
                placeBlock(x0 - x, y0 - y, z0 - z, value);
            }
        }
    }
}

/*
//按Ctrl键冲撞
event.addEventHandler("Frame", function () {
    if (game.world == null) {
        return;
    }
    if (isKeyDown(Keys.Control)) {
        with (game.world) {
            var viewDirection = subsystems.drawing.get_ViewDirection();
            var dx = viewDirection.X * 100;
            var dy = viewDirection.Y * 100;
            var dz = viewDirection.Z * 100;
            var impulse = new Vector3(dx, dy, dz);
            componentPlayer().get_ComponentBody().m_velocity = impulse;
        }
    }
});
*/

//生成一棵树
this.growOak = function (x, y, z) {
    if (typeof (_oaks) == "undefined") {
        _oaks = Game.PlantsManager.GetTreeBrushes(Game.TreeType.Oak);
    }
    var index = Math.floor(Math.random() * 16);
    _oaks[index].Paint(world.getSubsystem("Terrain"), x, y, z);
}
this.growBirch = function (x, y, z) {
    if (typeof (_birches) == "undefined") {
        _birches = Game.PlantsManager.GetTreeBrushes(Game.TreeType.Birch);
    }
    var index = Math.floor(Math.random() * 16);
    _birches[index].Paint(world.getSubsystem("Terrain"), x, y, z);
}
this.growSpruce = function (x, y, z) {
    if (typeof (_sprucess) == "undefined") {
        _spruces = Game.PlantsManager.GetTreeBrushes(Game.TreeType.Spruce);
    }
    var index = Math.floor(Math.random() * 16);
    _spruces[index].Paint(world.getSubsystem("Terrain"), x, y, z);
}

this.TerrainSpace = function (sizex, sizey, sizez) {
    this.sizex = sizex;
    this.sizey = sizey;
    this.sizez = sizez;
    this.blockarray = new Array(sizex * sizey * sizez);

    this.getBlock = function (x, y, z) {
        return this.blockarray[x + sizex * y + sizex * sizey * z];
    }
    this.setBlock = function (x, y, z, value) {
        this.blockarray[x + sizex * y + sizex * sizey * z] = value;
    }

    this.loadFrom = function (startx, starty, startz, endx, endy, endz) {
        var minx = Math.min(startx, endx);
        var miny = Math.min(starty, endy);
        var minz = Math.min(startz, endz);
        var maxx = Math.max(startx, endx);
        var maxy = Math.max(starty, endy);
        var maxz = Math.max(startz, endz);
        var world = new World();
        var areasizex = maxx - minx + 1;
        var areasizey = maxy - miny + 1;
        var areasizez = maxz - minz + 1;
        if (areasizex > this.sizex || areasizey > this.sizey || areasizez > this.sizez) {
            this.sizex = areasizex;
            this.sizey = areasizey;
            this.sizez = areasizez;
            this.blockarray = new Array(areasizex * areasizey * areasizez);
        }
        for (var x = 0; x < areasizex; ++x) {
            for (var y = 0; y < areasizey; ++y) {
                for (var z = 0; z <= areasizez; ++z) {
                    var value = world.getBlock(x + minx, y + miny, z + minz);
                    this.setBlock(x, y, z, value)
                }
            }
        }
    }
    this.writeTo = function (dstx, dsty, dstz) {
        var world = new World();
        for (var x = 0; x < this.sizex; ++x) {
            for (var y = 0; y < this.sizey; ++y) {
                for (var z = 0; z < this.sizez; ++z) {
                    var value = this.getBlock(x, y, z);
                    if (value == null) {
                        continue
                    }
                    world.setBlock(dstx + x, dsty + y, dstz + z, value);
                }
            }
        }
    }
}

//以下测试用
this.magic1 = function () {
    var world = new World();
    var x0 = Math.round(world.getPlayerX());
    var z0 = Math.round(world.getPlayerZ());
    var y0 = Math.round(world.getPlayerY());
    for (var x = 0; x < 16; ++x) {
        for (var z = 0; z < 16; ++z) {
            world.placeBlock(x0 + x, y0, z0 + z, 8);
            world.setTemperature(x0 + x, z0 + z, z);
            world.setHumidity(x0 + x, z0 + z, x);
        }
    }
}
this.magic2 = function () {
    var world = new World();
    var subsystem = world.subsystems.memoryBankBlockBehavior;
    //获得当前鼠标指向的方块的坐标
    if (subsystem == null) { return; }
    var point = world.pickTerrain().CellFace.Point;
    if (point == null) { return; }
    //获取该坐标的M板数据
    var data = subsystem.GetBlockData(point);
    if (data == null) {
        //如果选定M板为空，则创建一个M板数据，关联到选定M板
        data = new Game.MemoryBankData();
        subsystem.SetBlockData(point, data);
    }
    //清空数据
    for (var i = 0; i < 256; ++i) {
        data.Write(i, 0);
    }
    //写入数据
    data.Write(0x00, 2);
    data.Write(0x01, 3);
    data.Write(0x02, 3);
    data.Write(0x03, 3);
    data.Write(0x04, 3);
    data.Write(0x10, 4);
    data.Write(0x11, 6);
    data.Write(0x12, 6);
    data.Write(0x13, 6);
    data.Write(0x14, 6);
    //data.Read(0x00);
}

event.addEventHandler("GameLoaded", function () {
    //攻击必定命中
    var blocks = _Game.BlocksManager.m_blocks;
    for (var i = 0; i < blocks.length; ++i) {
        var block = blocks[i];
        block.DefaultMeleeHitProbability = 1.0;
        info("Block updated: " + block.DefaultDisplayName);
    }
});

event.addEventHandler("GameLoaded", function () {
    //高速飞行
    var gameDatabase = _Game.DatabaseManager.get_GameDatabase();
    var database = gameDatabase.get_Database();
    var guid = System.Guid.Parse("f51c8712-bd0d-43e8-810a-5abfd47db767");
    var databaseObject = database.FindDatabaseObject(guid, gameDatabase.get_ParameterType(), true);
    _Launcher.JsInterface.setDatabaseValue(databaseObject, 50.0);
})