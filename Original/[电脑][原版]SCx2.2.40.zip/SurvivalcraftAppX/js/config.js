﻿//要加载的模块
loadModule("addition", "app:js\\addition.js");
loadModule("event", "app:js\\event.js");
loadModule("game", "app:js\\game.js");
loadModule("example", "app:js\\example.js");
