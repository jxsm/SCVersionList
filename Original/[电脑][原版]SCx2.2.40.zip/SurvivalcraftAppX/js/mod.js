﻿var _Game = importNamespace("Game");
var _Engine = importNamespace("Engine");
var _GameEnitySystem = importNamespace("GameEnitySystem");
var _Launcher = importNamespace("Launcher");

var _findSubsystem = _Launcher.JsInterface.findSubsystem;
var _updatePlayerState = Launcher.JsInterface.updatePlayerState;

var info = _Engine.Log.Information;
var warn = _Engine.Log.Warning;
var error = _Engine.Log.Error;

function _Storage() {
    var storage = _Engine.storage;
    this.readAll = function (path) {
        return storage.ReadAllText(path);
    }
    this.writeAll = function (path, text) {
        storage.WriteAllText(path, text);
    }
    this.copyFile = function (source, destination) {
        storage.copyFile(source, destination);
    }
    this.moveFile = function (from, to) {
        storage.MoveFile(from, to);
    }
    this.createDirectory = function (path) {
        storage.CreateDirectory(path);
    }
    this.deleteDirectory = function (path) {
        storage.DeleteDirectory(path);
    }
    this.deleteFile = function (path) {
        storage.DeleteFile(path);
    }
    this.getFileNames=function(path){
        var enumerable = storage.GetFileNames(path);
        var filenames = [];
        var enumerator = enumerable.GetEnumerator();
        var f = true;
        while (f) {
            filenames.push(enumerator.get_Current());
            f = enumerator.MoveNext();
        }
        return filenames;
    }
    this.getDirectoryNames = function (path) {
        var enumerable = storage.GetDirectoryNames(path);
        var directorynames = [];
        var enumerator = enumerable.GetEnumerator();
        var f = true;
        while (f) {
            filenames.push(enumerator.get_Current());
            f = enumerator.MoveNext();
        }
        return directorynames;
    }
}

var storage = new _Storage();

function _Mod() {
    this.hooks = new Object();
    this.currentScreen = null;
    this.lastScreen = null;

    this.pushHook = function (hookName, callback) {
        if (typeof (this.hooks[hookName]) == "undefined") {
            this.hooks[hookName] = [callback];
        }
        else {
            this.hooks[hookName].push(callback);
        }
    };
    this.popHook = function (hookName) {
        if (typeof (this.hooks[hookName]) == "undefined") {
            return;
        }
        if (this.hooks[hookName].length == 0) {
            return;
        }
        this.hooks[hookName].pop();
    };
    this.activeHook = function (hookName, args) {
        if (typeof (this.hooks[hookName]) == "undefined") {
            return;
        }
        var hooks = this.hooks[hookName];
        for (var i = 0; i < hooks.length; ++i) {
            hooks[i].apply(this, args);
        }
    };
}

var mod = new _Mod();
var blocks = null;
var project = null;
var worldInfo = null;
var subsystems = null;
var terrainData = null;
var componentPlayer = null;

mod.pushHook("gameLoaded", function () {
    blocks = _Game.BlocksManager.get_Blocks();
});

mod.pushHook("worldLoaded", function () {
    project = _Game.GameManager.get_Project();
    worldInfo = _Game.GameManager.get_WorldInfo();
    subsystems = new Object();
    subsystemList = ["Gui", "Player", "Time", "TimeOfDay", "Sky", "Explosions", "GameInfo", "Camera", "Drawing", "BlockBehaviors", "Explosions", "Input", "Inventory", "Audio", "Terrain","pickables"];
    for (var i = 0; i < subsystemList.length; ++i) {
        var name = subsystemList[i];
        subsystems[name] = _findSubsystem(name);
    }
    terrainData = subsystems.Terrain.get_TerrainData();

});

mod.pushHook("screenChanged", function (screenName) {
    this.lastScreen = this.currentScreen;
    this.currentScreen = screenName;
});

mod.pushHook("screenChanged", function () {
    if (this.lastScreen == "RespawnScreen" && this.currentScreen == "GameScreen") {
        this.activeHook("playerRepawned");
    }
})


