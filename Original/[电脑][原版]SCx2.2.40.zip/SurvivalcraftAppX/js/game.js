﻿//游戏内容相关

var event = getModule("event");
var module = this;

function findSubsystem(name) {
    var type = _Game["Subsystem" + name];
    var project = _Game.GameManager.get_Project();
    if (project === null) {
        return;
    }
    return project.FindSubsystem(type, null, false);
}

//世界相关
function World() {
    var subsystems = new Object();
    subsystems.gui = findSubsystem("Gui");
    subsystems.player = findSubsystem("Player");
    subsystems.terrain = findSubsystem("Terrain");
    subsystems.timeOfDay = findSubsystem("TimeOfDay");
    subsystems.explosions = findSubsystem("Explosions");
    subsystems.drawing = findSubsystem("Drawing");
    subsystems.weather = findSubsystem("Weather");
    subsystems.sky = findSubsystem("Sky");
    subsystems.gameInfo = findSubsystem("GameInfo");
    subsystems.pickables = findSubsystem("Pickables");
    subsystems.memoryBankBlockBehavior = findSubsystem("MemoryBankBlockBehavior");
    subsystems.projectiles = findSubsystem("Projectiles");
	subsystems.particles = findSubsystem("Particles");
    subsystems.fireworks = findSubsystem("FireworksBlockBehavior");

    this.subsystems = subsystems;
    this.getSubsystem = function (name) {
        if (name in this.subsystems) {
            return this.subsystems[name];
        }
        var subsystem = findSubsystem(name);
        this.subsystems[name] = subsystem;
        return subsystem;
    };
    this.componentPlayer = function () { return this.subsystems.player.get_ComponentPlayer(); };
    this.worldInfo = subsystems.gameInfo.get_WorldInfo();

    this.message = function (text, blinking, playNotificationSound) {
        if (arguments.length == 1) {
            blinking = false;
            playNotificationSound = false;
        }
        this.subsystems.gui.DisplaySmallMessage(text, blinking, playNotificationSound);
    };
    this.getGameMode = function () {
        return parseInt(this.worldInfo.GameMode.toString());
    };
    this.setGameMode = function (mode) {
        this.worldInfo.GameMode = mode;
    };
    this.getTime = function () {
        return this.subsystems.timeOfDay.get_TimeOfDayOffset();
    };
    this.setTime = function (time) {
        this.subsystems.timeOfDay.set_TimeOfDayOffset(time);
    };
    this.getPlayerPosition = function () {
        return this.componentPlayer().get_ComponentBody().get_Position();
    };
    this.getPlayerX = function () {
        return this.getPlayerPosition().X;
    };
    this.getPlayerY = function () {
        return this.getPlayerPosition().Y;
    };
    this.getPlayerZ = function () {
        return this.getPlayerPosition().Z;
    };
    this.setPlayerPosition = function (x, y, z) {
        if (arguments.length == 1) {
            var position = arguments[0];
        }
        else {
            var position = new Vector3(x, y, z);
        }
        this.componentPlayer().get_ComponentBody().set_Position(position);
    };
    this.getHealth = function () {
        return this.componentPlayer().get_ComponentMiner().get_ComponentCreature().get_ComponentHealth().get_Health();
    };
    this.setHealth = function (health) {
        this.componentPlayer().get_ComponentMiner().get_ComponentCreature().get_ComponentHealth().set_Health(health);
    };
    this.getFood = function () {
        return this.componentPlayer().get_ComponentVitalStats().get_Food();
    };
    this.setFood = function (food) {
        this.componentPlayer().get_ComponentVitalStats().set_Food(food);
    };
    this.getBlock = function getBlock(x, y, z) {
        var terrainData = this.subsystems.terrain.get_TerrainData();
        return terrainData.GetCellValue(x, y, z);
    };
    this.getCellContents = function getCellContents(x, y, z) {
        return this.subsystems.terrain.TerrainData.ExtractContents(this.getBlock(x, y, z));
    };
    this.getCellData = function getCellData(x, y, z){
      return this.subsystems.terrain.TerrainData.ExtractData(this.getBlock(x, y, z));
    };
    this.getTopmostCellHeight = function getTopmostCellHeight(x,z){
      return this.subsystems.terrain.TerrainData.CalculateTopmostCellHeight(x, z);
    };
    this.getTemperature = function (x, z, temperature) {
        var terrainData = this.subsystems.terrain.get_TerrainData();
        return terrainData.GetTemperatureFast(x, z);
    };
    this.getHumidity = function (x, z, humidity) {
        var terrainData = this.subsystems.terrain.get_TerrainData();
        return terrainData.GetHumidityFast(x, z);
    };
    this.placeBlock = function (x, y, z, value) {
        this.subsystems.terrain.ChangeCell(x, y, z, value, true);
    };
    this.setBlock = function (x, y, z, value) {
        var subsystemTerrain = this.subsystems.terrain;
        var terrainData = subsystemTerrain.get_TerrainData();
        terrainData.SetCellValueFast(x, y, z, value);
        var terrainChunk = subsystemTerrain.CellToChunk(x, z);
        if (terrainChunk !== null) {
            terrainChunk.ModificationCounter++;
            subsystemTerrain.TerrainUpdater.DowngradeChunkNeighborhoodState(terrainChunk, 1, _Game.TerrainChunkState.InvalidLight, false);
        }
    };
    this.setTemperature = function (x, z, temperature) {
        var subsystemTerrain = this.subsystems.terrain;
        var terrainData = subsystemTerrain.get_TerrainData();
        terrainData.SetTemperatureFast(x, z, temperature);
        var terrainChunk = subsystemTerrain.CellToChunk(x, z);
        if (terrainChunk !== null) {
            terrainChunk.ModificationCounter++;
            subsystemTerrain.TerrainUpdater.DowngradeChunkNeighborhoodState(terrainChunk, 1, _Game.TerrainChunkState.InvalidLight, false);
        }
    };
    this.setHumidity = function (x, z, humidity) {
        var subsystemTerrain = this.subsystems.terrain;
        var terrainData = subsystemTerrain.get_TerrainData();
        terrainData.SetHumidityFast(x, z, humidity);
        var terrainChunk = subsystemTerrain.CellToChunk(x, z);
        if (terrainChunk !== null) {
            terrainChunk.ModificationCounter++;
            subsystemTerrain.TerrainUpdater.DowngradeChunkNeighborhoodState(terrainChunk, 1, _Game.TerrainChunkState.InvalidLight, false);
        }
    };
    this.addExplosion = function (x, y, z, pressure, noExplosionSound) {
        this.subsystems.explosions.AddExplosion(x, y, z, pressure, false, noExplosionSound);
    };
    this.makeLightningStrike = function (x, y, z) {
        var position;
        if (arguments.length === 0) {
            this.subsystems.weather.ManualLightingStrike();
        }
        else if (arguments.length == 1) {
            position = arguments[0];
        }
        else {
            position = new Vector3(x, y, z);
        }
        this.subsystems.sky.MakeLightningStrike(position);
    };
    this.addPickable = function (content, data, position, count) {
        var value = MakeBlockValue(content, 0, data);
        this.subsystems.pickables.AddPickable(value, count, position, null, null);
    };
    this.pickBody = function () {
        var componentMiner = this.componentPlayer().get_ComponentMiner();
        var subsystemDrawing = this.subsystems.drawing;
        return componentMiner.PickBody(subsystemDrawing.get_ViewPosition(), subsystemDrawing.get_ViewDirection());
    };
    this.pickTerrain = function () {
        var componentMiner = this.componentPlayer().get_ComponentMiner();
        var subsystemDrawing = this.subsystems.drawing;
        return componentMiner.PickTerrainForDigging(subsystemDrawing.get_ViewPosition(), subsystemDrawing.get_ViewDirection());
    };
    this.setWire = function (x, y, z, face) {
        var oldvalue = this.getBlock(x, y, z);
        var bitmask = Wire.getBitMask(oldvalue);
        bitmask = Wire.setOnFace(bitmask, face);
        var value = Wire.setBitMask(oldvalue, bitmask);
        this.setBlock(x, y, z, value);
    };
    this.getWire = function (x, y, z, face) {
        var value = this.getBlock(x, y, z);
        var bitmask = getBitMask(oldvalue);
        return Wire.getOnFace(bitmask, face);
    };
    this.throwBlock = function(blockValue, position, direction, owner) {
        var blockIndex = _Game.TerrainData.ExtractContents(blockValue);
        var block = _Game.BlocksManager.Blocks[blockIndex];
        var v = Vector3.op_Multiply(direction, block.ProjectileSpeed);
        this.subsystems.projectiles.FireProjectile(blockValue, position, v, new Vector3(0, 0, 0), owner);
    };
    this.throwBlockEx = function(blockValue, position, force, owner) {
        var blockIndex = _Game.TerrainData.ExtractContents(blockValue);
        var block = _Game.BlocksManager.Blocks[blockIndex];
        this.subsystems.projectiles.FireProjectile(blockValue, position, force, new Vector3(0, 0, 0), owner);
    };
    this.changeCamera = function (cameraClass) {
        var camera = new cameraClass(this.subsystems.camera);
        findSubsystem("Camera").set_ActiveCamera(camera);
    };
}

this.world = null;
event.addEventHandler("ScreenChanged", function (e) {
    if (e.currentScreenName == "Game") {
        if (module.world === null) {
            module.world = new World();
            info("game.js - World object created.");
        }
    }
    else if (e.currentScreenName == "MainMenu" && module.world !== null) {
        module.world = null;
        info("game.js - World object deleted");
    }
});
