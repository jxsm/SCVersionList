﻿//init.js功能上的扩展

var module = this;

//别名
vec2Add = Vector2.op_Addition;
vec2Sub = Vector2.op_Subtraction;
vec2Mul = Vector2.op_Multiply;
vec2Div = Vector2.op_Division;
vec2Equal = Vector2.op_Equality;
vec2Max = Vector2.Max;
vec2Min = Vector2.Min;
vec2Dot = Vector2.Dot;
vec2Cross = Vector2.Cross;
vec2Distance = Vector2.Distance;
vec2Ceiling = Vector2.Ceiling;
vec2Floor = Vector2.Floor;
vec2Normalize = Vector2.Normalize;
vec2Round = Vector2.Round;

vec3Add = Vector3.op_Addition;
vec3Sub = Vector3.op_Subtraction;
vec3Mul = Vector3.op_Multiply;
vec3Div = Vector3.op_Division;
vec3Equal = Vector3.op_Equality;
vec3Max = Vector3.Max;
vec3Min = Vector3.Min;
vec3Dot = Vector3.Dot;
vec3Cross = Vector3.Cross;
vec3Distance = Vector3.Distance;
vec3Ceiling = Vector3.Ceiling;
vec3Floor = Vector3.Floor;
vec3Normalize = Vector3.Normalize;
vec3Round = Vector3.Round;

//GUI相关
this.lastViewGameLogDialog = null;
this.showLog = function () {
    if (this.lastViewGameLogDialog != null) {
        _Game.DialogsManager.HideDialog(this.lastViewGameLogDialog);
    }
    var dialog = new _Game.ViewGameLogDialog();
    _Game.DialogsManager.ShowDialog(dialog);
    this.lastViewGameLogDialog = dialog;
}
this.messageBox = function (largeMessage, smallMessage, button1Text, button2Text, handler) {
    var messageDialog;
    if (arguments.length == 1) {
        messageDialog = new _Game.MessageDialog("Message", arguments[0], "OK", null, null);
    }
    else if (arguments.length == 2) {
        messageDialog = new _Game.MessageDialog(arguments[0], arguments[1], "OK", null, null);
    }
    else {
        messageDialog = new _Game.MessageDialog(largeMessage, smallMessage, button1Text, button2Text, handler);
    }
    _Game.DialogsManager.ShowDialog(messageDialog);
}
