﻿var addition = getModule("addition");
var module = this;

function Event() {
    this.handlers = new Array();
    this.addHandler = function (handler) {
        this.handlers.push(handler);
    }
    this.clearHandlers = function () {
        this.handlers.length = 0;
    }
    this.trigger = function () {
        var handlers = this.handlers;
        var eventObj = this;
        return function () {
            for (var i = 0; i < handlers.length; ++i) {
                handlers[i](eventObj, arguments);
            }
        }
    }
    this.triggerOnce = function () {
        for (var i = 0; i < this.handlers.length; ++i) {
            this.handlers[i](this, arguments);
        }
    }
}

this.events = {
    "Frame": new Event(),
    "KeyDown": new Event(),
    "KeyUp": new Event(),
    "ScreenChanged": new Event(),
    "GameLoaded": new Event()
};
this.addEventHandler = function (name, handler) {
    if (name in module.events)
        module.events[name].addHandler(handler);
    else {
        error("Event not found.");
    }
}

//Frame
_Engine.Window.add_Frame(this.events.Frame.trigger());

//KeyDown
this.events.KeyDown.addHandler(function (eventObj, arguments) {
    eventObj.Key = _Engine.Input.Key;
    eventObj.key = arguments[0];
});
this.events.KeyDown.enter = function (code) {
    if (code == "") { addition.showLog(); }
    try {
        var value = eval(code);
    }
    catch (e) {
        error(e.toString());
        addition.showLog();
    }
    this.lastCode = code;
    this.lastValue = value;
    try {
        info("JS "+code);
        info("=> " + value.toString());
    } catch (e) { }
    addition.showLog();
}
this.events.KeyDown.cancel = function () { }
this.events.KeyDown.addHandler(function (eventObj, arguments) {
    if (eventObj.Key.J == eventObj.key) {
        _Engine.Input.Keyboard.ShowKeyboard("JS 控制台", "输入你的JS代码: ", eventObj.lastCode, false, eventObj.enter, eventObj.cancel);
    }
});
this.events.KeyDown.lastCode = "";
_Engine.Input.Keyboard.add_KeyDown(this.events.KeyDown.trigger());
//KeyUp
this.events.KeyUp.addHandler(function (eventObj, arguments) {
    eventObj.Keys = _Engine.Input.Key;
    eventObj.key = arguments[0];
});
_Engine.Input.Keyboard.add_KeyUp(this.events.KeyUp.trigger());

//ScreenChanged
this.events.ScreenChanged.addHandler(function (event) {
    var currentScreen = _Game.ScreensManager.get_CurrentScreen();
    event.lastScreenName = event.currentScreenName;
    event.currentScreenName = _Game.ScreensManager.GetScreenName(currentScreen);
    if (event.lastScreenName == "Loading" && event.currentScreenName == "MainMenu") {
        module.events.GameLoaded.triggerOnce();
    }
});
//_Game.ScreensManager.add_ScreenChanged(this.events.ScreenChanged.trigger());